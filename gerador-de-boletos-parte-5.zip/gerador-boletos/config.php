<?php

define('CONF_ID', 'Client_Id_a4ebffe880db8973f370217cd828641d9d719b8a');
define('CONF_SECRETO', 'Client_Secret_d7a3ea356641ad85c88f2017415f756d8b875bd4');

?>