<?php

/**
 * CRIADO POR MAYKON SILVEIRA MAYKONSILVEIRA.COM.BR
 * PlayList:
 *  https://www.youtube.com/watch?v=skG8DCkAdM0&list=PLGFwuV_B-U2WtLv8YJAXr-RjNvNliTQhJ
 * 
 * NO MERCADO DA PROGRAMAÇÃO DESDE 2007 - EMPRESA PRÓPRIA DESDE 2010 
 * 
 * Curta nossa página: 
 * https://www.facebook.com/MaykonSilveiraMJ  
 * 
 * CURTA NOSSO CANAL https://www.youtube.com/channel/UC4p79Xbb2k1oDVy68nGQIMA 
 * 
 * E QUE O ETERNO PAI O CRIADOR DE TUDO E TODOS ABENÇOE A SUA VIDA M:24
 * 
 */


//CHAVES DO GERENCIANET gerencianet.com.br
require_once('config.php');

// AUTO LOAD PARA O COMPOSER
require_once('vendor/autoload.php');


use Gerencianet\Exception\GerencianetException;
use Gerencianet\Gerencianet;
 
$clientId = CONF_ID; // insira seu Client_Id, conforme o ambiente (Des ou Prod)
$clientSecret = CONF_SECRETO; // insira seu Client_Secret, conforme o ambiente (Des ou Prod)

$boleto = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRIPPED);

if(isset($boleto['gerarBoleto'])){

    unset($boleto['gerarBoleto']);

    echo $boleto['nome'] ."<hr>";
    echo $boleto['email'] ."<hr>";
    echo $boleto['fone'] ."<hr>";
    echo $boleto['cpf'] ."<hr>";
    echo $boleto['produto'] ."<hr>";
    echo $boleto['valor'] ."<hr>";
    echo $boleto['vencimento'] ."<hr>";

    $options = [
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'sandbox' => true // altere conforme o ambiente (true = Homologação e false = producao)
      ];
       
      $item_1 = [
          'name' => $boleto['produto'], // nome do item, produto ou serviço
          'amount' => 1, // quantidade
          'value' => intval($boleto['valor']) // valor (1000 = R$ 10,00) (Obs: É possível a criação de itens com valores negativos. Porém, o valor total da fatura deve ser superior ao valor mínimo para geração de transações.)
      ];
       

      $items =  [
          $item_1
      ];

      $body  =  [
        'items' => $items
    ];
    
    try {
        $api = new Gerencianet($options);
        $charge = $api->createCharge([], $body);
     
        //print_r($charge);
        header("Location: gerar-boleto.php?id=".$charge['data']['charge_id']."&nome=".$boleto['nome']."&cpf=".$boleto['cpf']."&fone=".$boleto['fone']."&vencimento=".$boleto['vencimento']);
    } catch (GerencianetException $e) {
        print_r($e->code);
        print_r($e->error);
        print_r($e->errorDescription);
    } catch (Exception $e) {
        print_r($e->getMessage());
    }

    
}

?>