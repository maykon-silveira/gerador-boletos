<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="css/estilos.css">
    <title>Gerador de Boletos PHP 8 - MAYKONSILVEIRA.COM.BR</title>
</head>
<body>

<!--
CRIADO POR EAD MAYKONSILVEIRA.COM.BR 
NO MERCADO DA PROGRAMAÇÃO DESDE 2007 - EMPRESA PRÓPRIA DESDE 2010 
-->

 <div>
  <h1>Gerador de Boletos - Maykon Silveira</h1>
  <form action="transacao.php" method="post">
  <input type="text" name="nome" placeholder="Nome completo">
  <input type="mail" name="email" placeholder="E-mail">
  <input type="number" name="fone" placeholder="Telefone">
  <input type="number" name="cpf" placeholder="CPF válido">
  <input type="text" name="produto" placeholder="Título do produto">
  <input type="number" name="valor" placeholder="Valor">
  <p>Data de vencimento</p>
  <input type="date" name="vencimento" >
  <button type="submit" class="btn" name="gerarBoleto">Gerar Boleto</button>
  </form>
 </div>

 <br>
<p>Criando por Maykon Silveira <a href="https://maykonsilveira.com.br" title="Cursos online grátis">MAYKONSILVEIRA.COM.BR</a></p>
</body>
</html>